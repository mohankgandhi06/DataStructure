package com.hospital.hospital_front_desk.models;

public class Hospital {

}