package com.hospital.hospital_front_desk.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.hospital_front_desk.models.Specialist;
import com.hospital.hospital_front_desk.services.SpecialistServices;

@RestController
@RequestMapping("/specialist")
public class SpecialistController {
	
	@Autowired
	private SpecialistServices specialistServices;
	
	@GetMapping
	@RequestMapping(value="/{hospital_name:[\\d]+}/{specialist_type}")
	public List<Specialist> listOfSpecialists(@PathVariable String hospital_name, @PathVariable String specialist_type) {
		return specialistServices.getList(hospital_name,specialist_type);	
	}
	/* Hospital Name, Specialist Type [INPUT] */
	/* XML, JSON [OUTPUT] */
}