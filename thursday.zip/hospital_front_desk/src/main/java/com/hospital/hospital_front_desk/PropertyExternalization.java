package com.hospital.hospital_front_desk;

import com.hospital.hospital_front_desk.properties.AdmissionProperties;
import com.hospital.hospital_front_desk.properties.HospitalProperties;
import com.hospital.hospital_front_desk.properties.SpecialistProperties;

public class PropertyExternalization {
	/* TODO class is not used anymore. tried to combine the property into a single one */
	public SpecialistProperties specialistProperties;
	public AdmissionProperties admissionProperties;
	public HospitalProperties hospitalProperties;

	/* Getters and Setters for the Property Files */
	public SpecialistProperties getSpecialistProperties() {
		return specialistProperties;
	}

	public void setSpecialistProperties(SpecialistProperties specialistProperties) {
		this.specialistProperties = specialistProperties;
	}

	public AdmissionProperties getAdmissionProperties() {
		return admissionProperties;
	}

	public void setAdmissionProperties(AdmissionProperties admissionProperties) {
		this.admissionProperties = admissionProperties;
	}

	public HospitalProperties getHospitalProperties() {
		return hospitalProperties;
	}

	public void setHospitalProperties(HospitalProperties hospitalProperties) {
		this.hospitalProperties = hospitalProperties;
	}
}