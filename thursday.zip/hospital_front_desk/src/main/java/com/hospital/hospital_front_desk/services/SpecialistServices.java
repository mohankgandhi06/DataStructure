package com.hospital.hospital_front_desk.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.hospital_front_desk.models.Specialist;
import com.hospital.hospital_front_desk.properties.SpecialistProperties;

@Service
public class SpecialistServices {

	@Autowired
	SpecialistProperties specialistProperties;
	
	public List<Specialist> getList(String hospital_name, String specialist_type) {
		System.out.println("hospital_name: " + hospital_name + " specialist_type: " + specialist_type);
		List<Specialist> list = specialistProperties.getSpecialistList();
		if (list == null) {
			System.out.println("RETURNED A NULL");
		}
		for (Specialist specialist : list) {
			System.out.println(specialist.getName());
		}
		return list;
	}
}