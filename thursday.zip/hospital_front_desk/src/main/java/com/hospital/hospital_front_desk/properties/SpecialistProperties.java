package com.hospital.hospital_front_desk.properties;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.hospital.hospital_front_desk.models.Specialist;

@Component
@Configuration
@PropertySource("classpath:specialist.properties")
@ConfigurationProperties("list")
public class SpecialistProperties {
	private List<Specialist> specialist = new ArrayList<Specialist>();

	public List<Specialist> getSpecialistList() {
		for(Specialist specialist: specialist) {
			System.out.println(specialist.getName());
		}
		return specialist;
	}

	public void setSpecialistList(List<Specialist> specialistList) {
		this.specialist = specialistList;
	}
}