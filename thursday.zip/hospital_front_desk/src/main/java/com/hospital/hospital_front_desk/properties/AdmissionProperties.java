package com.hospital.hospital_front_desk.properties;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:admission.properties")
public class AdmissionProperties {

}