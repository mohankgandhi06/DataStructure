package com.hospital.hospital_front_desk.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hospital.hospital_front_desk.models.Appointment;
import com.hospital.hospital_front_desk.models.Specialist;
import com.hospital.hospital_front_desk.properties.SpecialistProperties;

@Service
public class AppointmentServices {

	@Autowired
	SpecialistProperties specialistProperties;
	
	public Appointment bookAnAppointment(String specialist_name, String appointment_day, String patient_name) {
		/* TODO Reading from the specialist.properties is not working */
		List<Specialist> specialistList = specialistProperties.getSpecialistList();
		for(Specialist specialist: specialistList) {
			if(StringUtils.substringMatch(specialist.getAvailableDay(), 0, appointment_day) 
					&& specialist.getName().equalsIgnoreCase(specialist_name)) {
				return new Appointment(specialist.getName(), patient_name, appointment_day, specialist.getAvailableTime());
			}
		}
		return null;
	}
}