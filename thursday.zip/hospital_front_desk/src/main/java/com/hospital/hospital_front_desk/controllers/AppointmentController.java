package com.hospital.hospital_front_desk.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.hospital_front_desk.models.Appointment;
import com.hospital.hospital_front_desk.services.AppointmentServices;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {
	@Autowired
	private AppointmentServices appointmentServices;

	@GetMapping
	@RequestMapping(value = "/{specialist_name}/{appointment_day}/{patient_name}")
	public Appointment bookAnAppointment(@PathVariable String specialist_name, @PathVariable String appointment_day,
			@PathVariable String patient_name) {
		return appointmentServices.bookAnAppointment(specialist_name, appointment_day, patient_name);
	}
}