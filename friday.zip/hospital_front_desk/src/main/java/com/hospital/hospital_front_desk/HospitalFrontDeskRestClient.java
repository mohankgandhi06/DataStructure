package com.hospital.hospital_front_desk;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.hospital.hospital_front_desk.data.SpecialistVO;

public class HospitalFrontDeskRestClient {

	@Autowired
	/* TODO  */
	
	@GetMapping(value = "client/specialist/{port}/{environment}/{type}/{url}/{hospital_id}/{specialist_type}")
	public void getSpecialistList(@PathVariable("port") String port, @PathVariable("environment") String environment,
			@PathVariable("type") String type, @PathVariable("url") String url,
			@PathVariable("hospitalid") Integer hospital_id, @PathVariable("specialisttype") String specialist_type) {
		final String uri = "http://localhost:8080/springrestexample/employees/{id}";

		Map<String, String> params = new HashMap<>();
		params.put("id", "1");

		RestTemplate restTemplate = new RestTemplate();
		SpecialistVO result = restTemplate.getForObject(uri, SpecialistVO.class, params);

		System.out.println(result);
	}
}