package com.hospital.hospital_front_desk.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.hospital_front_desk.data.SpecialistVO;
import com.hospital.hospital_front_desk.services.SpecialistServices;

@RestController
@RequestMapping("/specialist")
public class SpecialistController {

	@Autowired
	private SpecialistServices specialistServices;

	@GetMapping(value = "/{hospital_name}/{specialist_type}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<SpecialistVO> listOfSpecialists(@PathVariable String hospital_name, @PathVariable String specialist_type) {
		SpecialistVO specialistList = specialistServices.getList(hospital_name, specialist_type);
		return new ResponseEntity<SpecialistVO>(specialistList, HttpStatus.OK);
	}
}