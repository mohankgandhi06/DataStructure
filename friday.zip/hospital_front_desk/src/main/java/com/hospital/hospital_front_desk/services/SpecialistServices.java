package com.hospital.hospital_front_desk.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.hospital_front_desk.data.Doctor;
import com.hospital.hospital_front_desk.data.SpecialistVO;
import com.hospital.hospital_front_desk.models.Specialist;
import com.hospital.hospital_front_desk.properties.SpecialistProperties;

@Service
public class SpecialistServices {

	@Autowired
	SpecialistProperties specialistProperties;

	public SpecialistVO getList(String hospital_name, String specialist_type) {
		SpecialistVO result = new SpecialistVO();
		List<Specialist> list = specialistProperties.getSpecialistList();
		for (Specialist specialist : list) {
			if (specialist.getHospitalName().equalsIgnoreCase(hospital_name)
					&& specialist.getType().equalsIgnoreCase(specialist_type)) {
				result.getItem().add(new Doctor(specialist));
			}
		}
		return result;
	}
}