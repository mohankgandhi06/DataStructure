package com.hospital.hospital_front_desk.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.hospital_front_desk.models.Appointment;
import com.hospital.hospital_front_desk.services.AppointmentServices;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {
	@Autowired
	private AppointmentServices appointmentServices;

	@GetMapping(value = "/{specialist_name}/{appointment_day}/{patient_name}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Appointment> bookAnAppointment(@PathVariable String specialist_name, @PathVariable String appointment_day,
			@PathVariable String patient_name) {
		Appointment appointment = appointmentServices.bookAnAppointment(specialist_name, appointment_day, patient_name);
		
		return new ResponseEntity<Appointment>(appointment, HttpStatus.OK);
	}
}