package com.hospital.hospital_front_desk.data;

import java.util.ArrayList;
import java.util.List;

public class SpecialistVO {
	java.util.List<Doctor> item;

	public SpecialistVO() {
		this.item = new ArrayList<Doctor>();
	}
	
	public SpecialistVO(List<Doctor> specialists) {
		super();
		this.item = specialists;
	}

	public java.util.List<Doctor> getItem() {
		return item;
	}

	public void setItem(java.util.List<Doctor> item) {
		this.item = item;
	}
}