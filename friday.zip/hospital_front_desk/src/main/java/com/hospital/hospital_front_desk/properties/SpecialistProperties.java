package com.hospital.hospital_front_desk.properties;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.hospital.hospital_front_desk.models.Specialist;

@Configuration
@PropertySource("classpath:specialist.properties")
@ConfigurationProperties("list")
public class SpecialistProperties {
	private List<Specialist> specialistList = new ArrayList<Specialist>();

	public List<Specialist> getSpecialistList() {
		return specialistList;
	}

	public void setSpecialistList(List<Specialist> specialistList) {
		this.specialistList = specialistList;
	}
}