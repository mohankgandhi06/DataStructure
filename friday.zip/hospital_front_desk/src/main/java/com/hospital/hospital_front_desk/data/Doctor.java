package com.hospital.hospital_front_desk.data;

import com.hospital.hospital_front_desk.models.Specialist;

public class Doctor {
	private String type;
	private String name;
	private String availableDay;
	private String availableTime;
	private String isAvailable;
	private String hospitalId;

	public Doctor() {
		
	}
	
	public Doctor(Specialist specialist) {
		this.type = specialist.getType();
		this.name = specialist.getName();
		this.availableDay = specialist.getAvailableDay();
		this.availableTime = specialist.getAvailableTime();
		this.isAvailable = specialist.getIsAvailable();
		this.hospitalId = specialist.getHospitalId();
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAvailableDay() {
		return availableDay;
	}

	public void setAvailableDay(String availableDay) {
		this.availableDay = availableDay;
	}

	public String getAvailableTime() {
		return availableTime;
	}

	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
}