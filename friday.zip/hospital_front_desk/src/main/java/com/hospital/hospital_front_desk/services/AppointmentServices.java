package com.hospital.hospital_front_desk.services;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.hospital_front_desk.models.Appointment;
import com.hospital.hospital_front_desk.models.Specialist;
import com.hospital.hospital_front_desk.properties.SpecialistProperties;

@Service
public class AppointmentServices {

	@Autowired
	SpecialistProperties specialistProperties;

	public Appointment bookAnAppointment(String specialist_name, String appointment_day, String patient_name) {
		List<Specialist> specialistList = specialistProperties.getSpecialistList();
		for (Specialist specialist : specialistList) {
			Pattern day = Pattern.compile(".*" + appointment_day + ".*", Pattern.CASE_INSENSITIVE);
			if (specialist.getName().equalsIgnoreCase(specialist_name)
					&& day.matcher(specialist.getAvailableDay()).matches()) {
				return new Appointment(specialist.getName(), patient_name, appointment_day,
						specialist.getAvailableTime());
			}
		}
		return null;
	}
}